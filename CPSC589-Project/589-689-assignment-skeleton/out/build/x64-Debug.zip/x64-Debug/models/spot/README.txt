spot_triangulated.obj was created by Keenan Crane, who released it into the public domain.
Source: https://www.cs.cmu.edu/~kmcrane/Projects/ModelRepository/
File was edited by Christopher Mossman to include normal data.


