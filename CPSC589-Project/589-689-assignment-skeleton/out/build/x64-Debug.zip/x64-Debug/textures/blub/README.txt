blub_texture.png was created by Keenan Crane, who released it into the public domain.
Source: https://www.cs.cmu.edu/~kmcrane/Projects/ModelRepository/
